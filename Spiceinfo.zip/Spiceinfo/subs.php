<?php

@$Email = $_POST["Email"];


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

$conn = mysqli_connect($servername, $username, $password, $dbname);

$sql = "INSERT INTO `test`.`subscribe` (`Email`) VALUES ('".$Email."')";

//$sql = "INSERT INTO `request`.`request` (`FirstName`, `LastName`, `SelectYourCourse`, `Phone`, `Message`) VALUES ('".$FirstName."','".$LastName."','".$SelectYourCourse."','".$Phone."','".$Message."')";

//echo $sql;


if (mysqli_query($conn, $sql)) {
    echo "Thank You For Subscribe";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}




?>